package com.employee.entity;

import java.time.LocalDate;
import java.util.List;
import javax.validation.constraints.*;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Employee {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;
	@NotBlank(message = "Employee ID is mandatory")
	@Column(nullable = false, unique = true)
	private String employeeId;
	@NotBlank(message = "First Name is mandatory")
    @Column(nullable = false)
	private String firstName;
	@NotBlank(message = "Last Name is mandatory")
    @Column(nullable = false)
	private String lastName;
	@Email(message = "Email shoul be valid")
	@NotBlank(message = "Email is Mandatory")
	private String email;
    @NotEmpty(message = "At least one phone number is required")
	private List<@Pattern(regexp = "\\d{10}", message = "Phone number should be 10 digits") String> phoneNumber;
    @NotNull(message = "Date of joining is Mandatory")
    @Column(nullable = false)
	private LocalDate doj;
    @Min(value = 0, message = "Salary must be Greater than or Equal to Zero")
    @Column(nullable = false)
	private double salary;
    
    
	public Employee() {
		super();
	}

	public Employee(Long id, @NotBlank(message = "Employee ID is mandatory") String employeeId,
			@NotBlank(message = "First Name is mandatory") String firstName,
			@NotBlank(message = "Last Name is mandatory") String lastName,
			@Email(message = "Email shoul be valid") @NotBlank(message = "Email is Mandatory") String email,
			@NotEmpty(message = "At least one phone number is required") List<@Pattern(regexp = "\\d{10}", message = "Phone number should be 10 digits") String> phoneNumber,
			@NotNull(message = "Date of joining is Mandatory") LocalDate doj,
			@Min(value = 0, message = "Salary must be Greater than or Equal to Zero") double salary) {
		super();
		this.id = id;
		this.employeeId = employeeId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.phoneNumber = phoneNumber;
		this.doj = doj;
		this.salary = salary;
	}
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public List<String> getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(List<String> phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public LocalDate getDoj() {
		return doj;
	}
	public void setDoj(LocalDate doj) {
		this.doj = doj;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
    

	@Override
	public String toString() {
		return "Employee [id=" + id + ", employeeId=" + employeeId + ", firstName=" + firstName + ", lastName="
				+ lastName + ", email=" + email + ", phoneNumber=" + phoneNumber + ", doj=" + doj + ", salary=" + salary
				+ "]";
	}
	

}
