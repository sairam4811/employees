package com.employee.service;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.employee.dto.EmployeeTaxInfo;
import com.employee.entity.Employee;
import com.employee.repository.EmployeeRepository;

@Service
public class EmployeeService {
	
	@Autowired
	private EmployeeRepository employeeRepository;
	
	public Employee saveEmployee(Employee employee) {
		return employeeRepository.save(employee);
	}
	
	public EmployeeTaxInfo calculateTax(String employeeId) {
		Employee employee = Optional.ofNullable(employeeRepository.findByEmployeeId(employeeId))
				.orElseThrow(() -> new RuntimeException("Employee Not Found"));
		LocalDate currentDate = LocalDate.now();
		int monthsWorked = (int) ChronoUnit.MONTHS.between(employee.getDoj().withDayOfMonth(1), currentDate.withDayOfMonth(1));
		int daysInJoiningMonth = employee.getDoj().lengthOfMonth() - employee.getDoj().getDayOfMonth() + 1;
		
		double totalSalary = employee.getSalary() * (monthsWorked - 1 ) + (employee.getSalary() / 30 * daysInJoiningMonth);
		
		double tax = 0;
		if (totalSalary > 1000000) {
            tax += (totalSalary - 1000000) * 0.20;
            totalSalary = 1000000;
        }
        if (totalSalary > 500000) {
            tax += (totalSalary - 500000) * 0.10;
            totalSalary = 500000;
        }
        if (totalSalary > 250000) {
            tax += (totalSalary - 250000) * 0.05;
        }

        double cess = 0;
        if (totalSalary > 2500000) {
            cess = (totalSalary - 2500000) * 0.02;
        }
        return new EmployeeTaxInfo(employee.getEmployeeId(), employee.getFirstName(), employee.getLastName(), employee.getSalary() * 12, tax, cess);
	}

}
